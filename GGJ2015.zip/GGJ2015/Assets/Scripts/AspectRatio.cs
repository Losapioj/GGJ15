﻿using UnityEngine;
using System.Collections;

public class AspectRatio : MonoBehaviour {

	// Use this for initialization
	void Start () {
		camera.aspect = 16.0f/9.0f;
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
